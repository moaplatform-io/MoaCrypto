module.exports = function (grunt) {
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        concat: {
            default: {
                src: ['ext/yahoo.js', 'ext/cj/core.js', 'ext/cj/x64-core.js', 'ext/cj/cipher-core.js', 
                'ext/cj/aes.js', 'ext/cj/tripledes.js', 'ext/cj/enc-base64.js', 'ext/cj/md5.js', 'ext/cj/sha1.js', 
                'ext/cj/sha256.js', 'ext/cj/sha224.js', 'ext/cj/sha512.js', 'ext/cj/sha384.js', 'ext/cj/ripemd160.js', 
                'ext/cj/hmac.js', 'ext/cj/pbkdf2.js', 'ext/cj/sha3.js', 
                'ext/cj/mode-ctr.js', 'ext/cj/pad-nopadding.js',
                'ext/cj/crypto-js.js',
                'ext/base64.js', 'ext/jsbn.js', 'ext/jsbn2.js', 
                'ext/prng4.js', 'ext/rng.js', 'ext/rsa.js', 'ext/rsa2.js', 'ext/ec.js', 'ext/ec-patch.js', 'ext/json-sans-eval.js',
                'src/asn1-1.0.js', 'src/asn1hex-1.1.js', 'src/asn1x509-1.0.js', 'src/asn1cms-1.0.js', 'src/asn1tsp-1.0.js', 
                'src/asn1cades-1.0.js', 'src/asn1csr-1.0.js', 'src/asn1ocsp-1.0.js', 'src/base64x-1.1.js', 'src/crypto-1.1.js', 
                'src/ecdsa-modified-1.0.js', 'src/ecparam-1.0.js', 'src/dsa-2.0.js', 'src/keyutil-1.0.js', 'src/rsapem-1.1.js', 
                'src/rsasign-1.2.js', 'src/x509-1.1.js', 'src/jws-3.3.js', 'src/jwsjs-2.0.js' ],
                dest: 'MoaClientECDSASignLib.js'
            }            
        },
        uglify: {            
            build: {
                src: 'MoaClientECDSASignLib.js',
                dest: 'MoaClientECDSASignLib.min.js'
            },
        },
    });

    grunt.loadNpmTasks('grunt-contrib-concat')
    grunt.loadNpmTasks('grunt-contrib-uglify')
    grunt.registerTask('default', ['concat', 'uglify']);
}
